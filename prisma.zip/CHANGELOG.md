# @shopify/shopify-app-template-remix

## v2024.08.06
Allow `SHOP_REDACT` webhook to process without admin context

## v2024.07.16

Started tracking changes and releases using calver
